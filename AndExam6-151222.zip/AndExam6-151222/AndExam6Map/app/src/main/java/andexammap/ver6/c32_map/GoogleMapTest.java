package andexammap.ver6.c32_map;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

import andexammap.ver6.R;

public class GoogleMapTest extends FragmentActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.googlemaptest);
    }
}