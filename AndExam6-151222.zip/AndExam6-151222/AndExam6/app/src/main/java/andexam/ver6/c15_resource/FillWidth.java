package andexam.ver6.c15_resource;

import andexam.ver6.*;
import android.app.*;
import android.os.*;

public class FillWidth extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fillwidth);
	}
}
