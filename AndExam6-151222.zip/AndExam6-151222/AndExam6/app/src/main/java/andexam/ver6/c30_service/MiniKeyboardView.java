package andexam.ver6.c30_service;

import android.content.*;
import android.inputmethodservice.*;
import android.util.*;

public class MiniKeyboardView extends KeyboardView {
	public MiniKeyboardView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public MiniKeyboardView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}
}
