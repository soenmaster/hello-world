package andexam.ver6.c13_advwidget;

import andexam.ver6.*;
import android.app.*;
import android.os.*;

public class SpaceTest extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.spacetest);
	}
}