package andexam.ver6.c11_widget;

import andexam.ver6.*;
import android.app.*;
import android.os.*;

public class YesNinePatch extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.yesninepatch);
	}
}