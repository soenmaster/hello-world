package andexam.ver6.c06_layoutman;

import andexam.ver6.*;
import android.app.*;
import android.os.*;

public class NestLayout extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.nestlayout);
	}
}