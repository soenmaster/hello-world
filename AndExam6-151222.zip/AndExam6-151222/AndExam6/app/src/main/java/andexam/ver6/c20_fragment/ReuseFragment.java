package andexam.ver6.c20_fragment;

import android.app.*;
import android.os.*;
import andexam.ver6.*;

public class ReuseFragment extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.reusefragment);
	}
}