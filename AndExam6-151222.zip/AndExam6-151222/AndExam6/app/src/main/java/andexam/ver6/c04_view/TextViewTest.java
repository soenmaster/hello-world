package andexam.ver6.c04_view;

import andexam.ver6.*;
import android.app.*;
import android.os.*;

public class TextViewTest extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.textviewtest);
	}
}