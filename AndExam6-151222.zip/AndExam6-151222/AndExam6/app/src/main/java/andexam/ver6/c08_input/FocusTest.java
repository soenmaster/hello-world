package andexam.ver6.c08_input;

import andexam.ver6.*;
import android.app.*;
import android.os.*;

public class FocusTest extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.focustest);
	}
}