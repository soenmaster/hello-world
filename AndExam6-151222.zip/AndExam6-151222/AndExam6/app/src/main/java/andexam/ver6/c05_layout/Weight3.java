package andexam.ver6.c05_layout;

import andexam.ver6.*;
import android.app.*;
import android.os.*;

public class Weight3 extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.weight3);
	}
}